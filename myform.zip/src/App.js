// import logo from './logo.svg';
import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Search_filter from './Component/Search_filter';
import Home from './Component/Home';
import Register from './Component/Register';
import Login from './Component/Login';
function App() {
  return (
    <div className="App">
      <ToastContainer theme='colored'></ToastContainer>
<BrowserRouter>
<Routes>
  <Route path ='/' element= {<Home />}></Route>
  <Route path ='/login' element= {<Login />}></Route>
  <Route path ='/register' element= {<Register />}></Route>
  <Route path ='/Search_filter' element= {<Search_filter />}></Route>
</Routes>
</BrowserRouter>
    </div>
  );
}

export default App;
