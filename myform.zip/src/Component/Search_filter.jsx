import React, { useState, useEffect } from 'react';
import axios from 'axios';


function Search_filter() {
    const[data, setData] = useState([]);
    const[filterVal, setfilterVal] = useState([]);
    const [searchApiData, setsearchApiData] = useState([]);
    function getData()
    {
        axios.get(`http://localhost:8000/user`)
        .then((res) => {
            console.log(res.data);
            setData(res.data);
            setsearchApiData(res.data);
        });
}
    
     const setToLocalStorage = (id,name,email,phone,country) => 
    {
      localStorage.setItem("id" , id)
      localStorage.setItem("name" , name);
      localStorage.setItem("email" , email);
      localStorage.setItem("phone" , phone);
      localStorage.setItem("country" , country);
    } 
    useEffect(() => {
      getData(); 
    },[]);
    const handleFilter =(e)=> {
      if(e.target.value == ''){
        setData(searchApiData)
      } else {
       const filterResult = searchApiData.filter(item => item.name.toLowerCase().includes(e.target.value.toLowerCase()) 
      || item.id.toLowerCase().includes(e.target.value.toLowerCase()) 
      || item.phone.toLowerCase().includes(e.target.value.toLowerCase())
      || item.email.toLowerCase().includes(e.target.value.toLowerCase())
      || item.country.toLowerCase().includes(e.target.value.toLowerCase()))
      if(filterResult.length > 0)
      {
        setData(filterResult)
      } else {
        setData([{"name" : "No data Found"}])
       }
      }

      setfilterVal(e.target.value)
      }
  return (
    <div style={{margin:'20px 20%'}}>
      <div className='p-input-icon-right'>
        <input type='search' placeholder='Search' value={filterVal} onInput={(e)=>handleFilter(e)} />
      </div>
          <table class="table">
  <thead>
    <tr>
      <th scope="col">ID</th>
      <th scope="col">name</th>
      <th scope="col">Email</th>
      <th scope="col">Phone</th>
      <th scope="col">Country</th>
    </tr>
  </thead>
    
  {data.map((eachData) => {
    return(
      <>
        <tbody onClick={()=> setToLocalStorage(eachData.id,eachData.name,eachData.email,eachData.phone,eachData.country)}>
    <tr>
      <th scjope="row">{eachData.id}</th>
      <td>{eachData.name}</td>
      <td>{eachData.email}</td>
      <td>{eachData.phone}</td>
      <td>{eachData.country}</td>
    </tr>
  </tbody>
      </>
    );
  })
   }
  </table>
  </div>
  );
};

export default Search_filter