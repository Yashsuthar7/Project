import React, { useEffect, useState } from 'react'
import '../App.css';
import { Link } from 'react-router-dom';

function CartList({ cart }) {
    const [CART, setCART] = useState([])
    useEffect(() => {
        setCART(cart)
    }, [])
    return (
        <div>
           
        <div className="container">
            <div className="row">
            <div className="col-lg-8" style={{ marginTop: 30 }}>
                <div className="shopping__cart__table">
                <thead>
                    <tr>
                <th>Product</th>
                <th>Quantity</th>
                <th>Total</th>
                    </tr>
                </thead>
                {
                CART.map((cartItem, cartindex) => {
                    return (
                <table>
             
                <tbody>
    <tr>
            <td className="product__cart__item">
                <div className="product__cart__item__pic">
                <img src={cartItem.url} width={40} />
         </div>
             <div className="product__cart__item__text">
                     <span className='product__cart__item__text'> {cartItem.name}  | {cartItem.category}</span>
              {/* <span> {productItem.seller} </span> */}
         </div>
     </td>
     <div className='plus_minus_btn'>
            <button onClick={() => {
                const _CART = CART.map((item, index) => {
    return cartindex === index ? { ...item, quantity: item.quantity > 0 ? item.quantity - 1 : 0 } : item })
         setCART(_CART)
                        }}>-</button>
        <span> {cartItem.quantity} </span>
            <button onClick={() => {
    const _CART = CART.map((item, index) => {
    return cartindex === index ? { ...item, quantity: item.quantity + 1 } : item })
         setCART(_CART)
                  }}>+</button>
                 
                  </div>
                  <span className='rs'>₹ {cartItem.price * cartItem.quantity}</span>
            <td className="cart__close"><i className="fa fa-close" /></td>
    </tr>

         </tbody>
    </table>
    )
                })
            }
         </div>
                                    <div className="row">
                                        <div className="col-lg-6 col-md-6 col-sm-6">
                                            <div className="continue__btn">
                                                <a href="/">Continue Shopping</a>
                                            </div>
                                        </div>
                                        <div className="col-lg-6 col-md-6 col-sm-6">
                                            <div className="continue__btn update__btn">
                                                <a href="/">
                                                    <i className="fa fa-spinner" /> Update cart</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-lg-4" style={{ marginTop: 30 }}>
                                    <div className="cart__discount">
                                        <h6>Discount codes</h6>
                                        <form action="#">
                                            <input type="text" placeholder="Coupon code" />
                                            <button type="submit">Apply</button>
                                        </form>
                                    </div>
                                    <div className="cart__total">
                                        <h6>Cart total</h6>
                                        <ul>
                                        <li>Sub-Total : <span>₹
                {
                    CART.map(item => item.price * item.quantity).reduce((total, value) => total + value, 0)
                }
            </span></li>
                                            <li>Total : <span>₹ 
                {
                    CART.map(item => item.price * item.quantity).reduce((total, value) => total + value, 0)
                }
            </span></li>
                                        </ul>
                                        <Link to="../Checkout" className="primary-btn" style={{ color: 'white' }}>Proceed to checkout</Link>
                                    </div>
                                </div>
                            </div>
                        </div>

            
            
        </div>
    )
}

export default CartList


// <div>
// <img src={cartItem.url} width={40} />
// <span> {cartItem.name} </span>
// <button onClick={()=> {
//  const _CART = CART.map((item, index) =>{
//      return cartindex === index ? { ...item, quantity: item.quantity > 0 ? item.quantity -1 : 0} : item
//  })
//  setCART(_CART)
// }}
// >-</button>
// <span> { cartItem.quantity} </span>
// <button onClick={()=> {
//  const _CART = CART.map((item, index) =>{
//      return cartindex === index ? { ...item, quantity: item.quantity + 1} : item
//  })
//  setCART(_CART)
// }}
// >+</button>
// <span>₹ { cartItem.price * cartItem.quantity}</span>

// </div>