import React from 'react'

function Header(props) {
  return (
    <div className='flex shopping-card'>
        <div onClick={()=> props.handleShow(false)}>Shopping Cart App</div>
        <div onClick={()=> props.handleShow(true)}>
        <i class="fa fa-shopping-cart" aria-hidden="true"></i>

          <sup>{props.count}</sup>
        </div>
    </div>
  )
}

export default Header